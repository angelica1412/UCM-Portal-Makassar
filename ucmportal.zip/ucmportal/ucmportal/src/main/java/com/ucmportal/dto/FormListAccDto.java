package com.ucmportal.dto;

import com.ucmportal.entities.Form;

public class FormListAccDto {
    private byte[] logo;
    private String title;
    private String type;
    public FormListAccDto() {
    }
    public FormListAccDto(byte[] logo, String title, String type) {
        this.logo = logo;
        this.title = title;
        this.type = type;
    }
    public static FormListAccDto fromForm(Form form) {
        FormListAccDto formListAccDto = new FormListAccDto();
        formListAccDto.setLogo(form.getLogo());
        formListAccDto.setTitle(form.getTitle());
        formListAccDto.setType(form.getType());
        return formListAccDto;
    }
    public byte[] getLogo() {
        return logo;
    }
    public void setLogo(byte[] logo) {
        this.logo = logo;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
}
