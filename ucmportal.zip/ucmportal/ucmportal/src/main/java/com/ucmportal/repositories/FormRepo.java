package com.ucmportal.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ucmportal.entities.Form;
import com.ucmportal.entities.User;

@Repository
public interface FormRepo extends JpaRepository<Form, Long> {
    List<Form> findByTitleContainsIgnoreCase(String title);
    List<Form> findByUser(User user);
    List<Form> findByTitle(String title);
    List<Form> findByStatus(String status);
    
}
