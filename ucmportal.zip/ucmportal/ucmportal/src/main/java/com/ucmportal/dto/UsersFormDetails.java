package com.ucmportal.dto;

/**
 * UsersFormDetails
 */
public class UsersFormDetails {
    private String userName;
    private Long nim;
    private String major;
    private String formTitle;

    public UsersFormDetails(String userName, Long nim, String major, String formTitle) {
        this.userName = userName;
        this.nim = nim;
        this.major = major;
        this.formTitle = formTitle;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Long getNim() {
        return nim;
    }

    public void setNim(Long nim) {
        this.nim = nim;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getFormTitle() {
        return formTitle;
    }

    public void setFormTitle(String formTitle) {
        this.formTitle = formTitle;
    }

}