package com.ucmportal.dto;

public class UserSummaryDto {
    private String name;
    private String userLevel;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(String userLevel) {
        this.userLevel = userLevel;
    }

    public UserSummaryDto(String name, String userLevel) {
        this.name = name;
        this.userLevel = userLevel;
    }
}
